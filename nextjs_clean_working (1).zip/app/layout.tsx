import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Jersey Elite Coatings',
  description: 'Epoxy flooring & coatings in New Jersey',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
