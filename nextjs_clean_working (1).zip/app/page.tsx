import { HomeDesktop } from '@/screens/HomeDesktop/HomeDesktop';

export default function Page() {
  return <HomeDesktop />;
}
